# simple_test.py
import asyncio
from aiogram import Bot, Dispatcher, Router
from aiogram.filters import CommandStart
from aiogram.types import Message
from aiogram.fsm.storage.memory import MemoryStorage


async def simple_test():
    """Простой тест с минимальным токеном формата"""
    print("🤖 ПРОСТОЙ ТЕСТ СТРУКТУРЫ...")

    # Используем валидный формат токена (должен быть в .env)
    from app.config import settings

    try:
        bot = Bot(token=settings.bot_token)
        dp = Dispatcher(storage=MemoryStorage())

        # Создаем тестовый роутер
        test_router = Router()

        @test_router.message(CommandStart())
        async def cmd_start(message: Message):
            await message.answer("Тест: старт работает!")

        dp.include_router(test_router)

        # Проверяем
        handlers = list(dp.message.handlers)
        print(f"✅ Тестовый роутер: {len(handlers)} хендлеров")

        if handlers:
            print(f"🎉 Структура работает! Можно запускать бота.")
            return True
        else:
            print("❌ Хендлеры не зарегистрированы")
            return False

    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return False


if __name__ == "__main__":
    asyncio.run(simple_test())