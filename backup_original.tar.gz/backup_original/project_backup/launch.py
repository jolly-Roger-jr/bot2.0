# В launch.py после создания dp добавьте:

print("\n📦 ПОДКЛЮЧЕНИЕ СУЩЕСТВУЮЩИХ ХЕНДЛЕРОВ...")

# Подключаем существующие user хендлеры
try:
    from app.handlers.user.start import router as start_router
    dp.include_router(start_router)
    print("✅ Существующий /start подключен")
except Exception as e:
    print(f"⚠️ Существующий /start: {e}")

try:
    from app.handlers.user.catalog import router as catalog_router
    dp.include_router(catalog_router)
    print("✅ Существующий каталог подключен")
except Exception as e:
    print(f"⚠️ Существующий каталог: {e}")

try:
    from app.handlers.user.cart import router as cart_router
    dp.include_router(cart_router)
    print("✅ Существующая корзина подключена")
except Exception as e:
    print(f"⚠️ Существующая корзина: {e}")

# Подключаем admin роутер
try:
    from app.handlers.admin import router as admin_router
    dp.include_router(admin_router)
    print("✅ Существующая админка подключена")
except Exception as e:
    print(f"⚠️ Существующая админка: {e}")

# Проверяем итоговое количество хендлеров
handlers = list(dp.message.handlers)
print(f"\n📊 ВСЕГО ХЕНДЛЕРОВ СЕЙЧАС: {len(handlers)}")