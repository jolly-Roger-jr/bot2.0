# check_env.py
import os
from dotenv import load_dotenv

print("🔍 Проверка .env файла...")

load_dotenv()

print("Содержимое .env:")
print(f"BOT_TOKEN: {'*' * 20}{os.getenv('BOT_TOKEN', '')[-5:] if os.getenv('BOT_TOKEN') else 'НЕТ'}")
print(f"ADMIN_ID: {os.getenv('ADMIN_ID')}")
print(f"TIMEZONE: {os.getenv('TIMEZONE')}")
print(f"DATABASE_URL: {os.getenv('DATABASE_URL')}")

# Проверяем валидность
errors = []
if not os.getenv('BOT_TOKEN'):
    errors.append("❌ BOT_TOKEN не найден")
elif len(os.getenv('BOT_TOKEN')) < 30:
    errors.append("❌ BOT_TOKEN слишком короткий")

if not os.getenv('ADMIN_ID'):
    errors.append("❌ ADMIN_ID не найден")
else:
    try:
        admin_id = int(os.getenv('ADMIN_ID'))
        print(f"✅ ADMIN_ID валиден: {admin_id}")
    except:
        errors.append("❌ ADMIN_ID должен быть числом")

if not os.getenv('DATABASE_URL'):
    errors.append("❌ DATABASE_URL не найден")

if errors:
    print("\n❌ Ошибки в .env:")
    for error in errors:
        print(f"  {error}")
else:
    print("\n✅ .env файл корректен!")