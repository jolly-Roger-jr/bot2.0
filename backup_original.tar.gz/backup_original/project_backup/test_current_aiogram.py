# test_current_aiogram.py - ТЕКУЩАЯ ПРОВЕРКА
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

print("🧪 Проверка текущей установки...")

# 1. Проверяем импорт
try:
    import aiogram

    print(f"✅ Aiogram версия: {aiogram.__version__}")
except ImportError as e:
    print(f"❌ Нет aiogram: {e}")
    sys.exit(1)

# 2. Проверяем синтаксис aiogram 3.x
print("\n🤖 Тест aiogram 3.x синтаксиса...")
try:
    from aiogram import Bot, Dispatcher, Router, F
    from aiogram.filters import Command
    from aiogram.types import Message
    from aiogram.fsm.storage.memory import MemoryStorage

    print("✅ Импорт aiogram 3.x успешен")

    # Создаем роутер
    test_router = Router()


    # Регистрируем хендлер
    @test_router.message(Command("test"))
    async def test_handler(message: Message):
        print("✅ Хендлер должен сработать")


    # Создаем диспетчер
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(test_router)

    # Проверяем
    handlers = list(dp.message.handlers)
    print(f"📊 Хендлеров зарегистрировано: {len(handlers)}")

    if len(handlers) > 0:
        print("🎉 AIOGRAM 3.x РЕГИСТРИРУЕТ ХЕНДЛЕРЫ!")
        print("Проблема в твоих файлах, не в установке")

        # Показываем что за хендлер
        for i, h in enumerate(handlers[:2], 1):
            print(f"  {i}. {h}")
    else:
        print("❌ AIOGRAM 3.x НЕ РЕГИСТРИРУЕТ ХЕНДЛЕРЫ!")
        print("Нужно переустановить aiogram")

except Exception as e:
    print(f"❌ Ошибка: {e}")
    import traceback

    traceback.print_exc()