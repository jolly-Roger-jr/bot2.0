# minimal_working_bot.py - АБСОЛЮТНЫЙ МИНИМУМ
import asyncio
import logging

# Отключаем лишние логи
logging.basicConfig(level=logging.WARNING)


async def main():
    print("🤖 АБСОЛЮТНО МИНИМАЛЬНЫЙ ТЕСТ...")

    # Проверяем самый базовый импорт
    from aiogram import Bot, Dispatcher, Router
    from aiogram.filters import Command
    from aiogram.types import Message

    print("✅ Импорт прошел")

    # Создаем роутер
    router = Router()

    # Хендлер 1
    @router.message(Command("start"))
    async def start_handler(message: Message):
        return

    # Хендлер 2
    @router.message(Command("help"))
    async def help_handler(message: Message):
        return

    # Создаем диспетчер
    dp = Dispatcher()
    dp.include_router(router)

    # Проверяем
    handlers = list(dp.message.handlers)
    print(f"📊 Хендлеров зарегистрировано: {len(handlers)}")

    if len(handlers) > 0:
        print("🎉 УСПЕХ! Aiogram работает")
        for i, h in enumerate(handlers, 1):
            print(f"  {i}. {h}")
    else:
        print("❌ ПРОВАЛ! Aiogram не регистрирует хендлеры")

        # Пробуем альтернативный способ
        print("\n🔧 Пробуем альтернативный способ...")

        # Создаем новый роутер
        router2 = Router()

        # Регистрируем хендлер напрямую
        async def test_handler(message: Message):
            return

        router2.message.register(test_handler, Command("test"))

        dp2 = Dispatcher()
        dp2.include_router(router2)

        handlers2 = list(dp2.message.handlers)
        print(f"📊 Альтернативный способ: {len(handlers2)} хендлеров")


if __name__ == "__main__":
    asyncio.run(main())