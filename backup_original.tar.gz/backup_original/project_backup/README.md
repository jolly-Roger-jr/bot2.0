# 🐶 Barkery Bot - Интернет-магазин собачьих лакомств

Telegram бот для магазина натуральных сушеных собачьих лакомств "Barkery".

## 🚀 Быстрый старт

### 1. Клонирование и настройка
```bash
git clone <repository-url>
cd barkery_bot