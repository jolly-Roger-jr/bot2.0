# bot.py - МИНИМАЛЬНЫЙ РАБОЧИЙ БОТ
import asyncio
import logging
from aiogram import Bot, Dispatcher, Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message
from aiogram.fsm.storage.memory import MemoryStorage
import os
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%H:%M:%S"
)

TOKEN = os.getenv("BOT_TOKEN")
if not TOKEN:
    print("❌ ОШИБКА: Добавь BOT_TOKEN в .env файл")
    print("Пример .env:")
    print("BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrSTUvwxYZ")
    print("ADMIN_ID=161165462")
    exit(1)

router = Router()

@router.message(CommandStart())
async def start(message: Message):
    await message.answer("✅ Бот работает! Команда /start выполнена.")

@router.message(Command("help"))
async def help(message: Message):
    await message.answer("ℹ️ Помощь: /start, /help, /test")

@router.message(Command("test"))
async def test(message: Message):
    await message.answer("🎉 Тест пройден!")

async def main():
    print("🤖 Запуск бота...")
    bot = Bot(token=TOKEN)
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)
    handlers = list(dp.message.handlers)
    print(f"📊 Хендлеров зарегистрировано: {len(handlers)}")
    if len(handlers) == 0:
        print("❌ ОШИБКА: Хендлеры не зарегистрированы!")
        return
    print("🚀 Бот запущен! Отправь /start в Telegram")
    try:
        await dp.start_polling(bot)
    except KeyboardInterrupt:
        print("\n⏹ Остановка")
    except Exception as e:
        print(f"❌ Ошибка: {e}")

if __name__ == "__main__":
    asyncio.run(main())