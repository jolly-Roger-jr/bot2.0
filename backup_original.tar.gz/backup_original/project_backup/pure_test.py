# pure_test.py
import asyncio
import logging
import sys
import os

# Добавляем текущую директорию
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

print("🧪 АБСОЛЮТНО ЧИСТЫЙ ТЕСТ AIOGRAM")

# Отключаем логи
logging.basicConfig(level=logging.WARNING)


async def test():
    try:
        from aiogram import Bot, Dispatcher, Router, F
        from aiogram.filters import CommandStart, Command
        from aiogram.types import Message
        from aiogram.fsm.storage.memory import MemoryStorage

        print("✅ Импорты успешны")

        # Создаем простейшего бота
        bot = Bot(token="dummy_token_12345")  # Неправильный токен, но для теста структуры сойдет
        dp = Dispatcher(storage=MemoryStorage())

        router = Router()

        # Хендлер 1
        @router.message(CommandStart())
        async def cmd_start(message: Message):
            pass

        # Хендлер 2
        @router.message(Command("test"))
        async def cmd_test(message: Message):
            pass

        # Хендлер 3 (через F)
        @router.message(F.text == "ping")
        async def cmd_ping(message: Message):
            pass

        # Включаем роутер
        dp.include_router(router)

        # Проверяем
        msg_handlers = list(dp.message.handlers)
        cb_handlers = list(dp.callback_query.handlers)

        print(f"📊 Результат:")
        print(f"  📨 Хендлеров сообщений: {len(msg_handlers)}")
        print(f"  🔄 Хендлеров callback: {len(cb_handlers)}")

        if len(msg_handlers) > 0:
            print("🎉 AIOGRAM РАБОТАЕТ КОРРЕКТНО!")
            print("Проблема в вашем проекте, а не в aiogram")
            for i, h in enumerate(msg_handlers[:3], 1):
                print(f"  {i}. {h}")
        else:
            print("❌ AIOGRAM НЕ РЕГИСТРИРУЕТ ХЕНДЛЕРЫ!")
            print("Возможные причины:")
            print("1. Поврежденная установка aiogram")
            print("2. Конфликт версий Python")
            print("3. Кэшированные файлы .pyc")

        await bot.session.close()

    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(test())