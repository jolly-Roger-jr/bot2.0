# diagnose.py - создайте этот файл в корне проекта

import asyncio
import logging
import sys
import os

# Добавляем путь к проекту в sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage

from app.config import settings
from app.handlers.user import router as user_router
from app.handlers.admin import router as admin_router

logging.basicConfig(level=logging.INFO)


async def diagnose():
    print("=" * 60)
    print("ДИАГНОСТИКА РЕГИСТРАЦИИ ХЕНДЛЕРОВ")
    print("=" * 60)

    try:
        bot = Bot(token=settings.bot_token)
    except Exception as e:
        print(f"❌ Ошибка создания бота: {e}")
        return

    dp = Dispatcher(storage=MemoryStorage())

    # Регистрируем роутеры
    dp.include_router(user_router)
    dp.include_router(admin_router)

    # Проверяем хендлеры в user_router
    print("\n📊 User Router хендлеры:")
    user_msg_handlers = list(user_router.message.handlers)
    user_callback_handlers = list(user_router.callback_query.handlers)
    print(f"  Сообщения: {len(user_msg_handlers)}")
    print(f"  Callbacks: {len(user_callback_handlers)}")

    if user_msg_handlers:
        print(f"  Примеры message handlers:")
        for i, handler in enumerate(user_msg_handlers[:3], 1):
            try:
                # Пытаемся получить информацию о фильтрах
                filters_str = ""
                if hasattr(handler, 'filters'):
                    filters_str = str(handler.filters)
                print(f"    {i}. Фильтры: {filters_str}")
            except:
                print(f"    {i}. <информация недоступна>")

    # Проверяем хендлеры в admin_router
    print("\n📊 Admin Router хендлеры:")
    admin_msg_handlers = list(admin_router.message.handlers)
    admin_callback_handlers = list(admin_router.callback_query.handlers)
    print(f"  Сообщения: {len(admin_msg_handlers)}")
    print(f"  Callbacks: {len(admin_callback_handlers)}")

    if admin_msg_handlers:
        print(f"  Примеры message handlers:")
        for i, handler in enumerate(admin_msg_handlers[:3], 1):
            try:
                # Пытаемся получить информацию о фильтрах
                filters_str = ""
                if hasattr(handler, 'filters'):
                    filters_str = str(handler.filters)
                print(f"    {i}. Фильтры: {filters_str}")
            except:
                print(f"    {i}. <информация недоступна>")

    # Проверяем итоговые хендлеры в диспетчере
    print("\n📊 ИТОГО в диспетчере:")
    total_msg = list(dp.message.handlers)
    total_callback = list(dp.callback_query.handlers)
    print(f"  Сообщения: {len(total_msg)}")
    print(f"  Callbacks: {len(total_callback)}")

    # Дополнительная проверка команд
    print("\n🔍 Проверка конкретных команд:")
    commands_to_check = ['/start', '/admin', '/cart', '/help']

    for cmd in commands_to_check:
        # Ищем хендлеры для каждой команды
        handlers_for_cmd = []
        for handler in total_msg:
            try:
                # Проверяем фильтры хендлера
                if hasattr(handler, 'filters'):
                    filters = handler.filters
                    # Простая проверка (не идеальная, но для диагностики)
                    if cmd in str(filters):
                        handlers_for_cmd.append(handler)
            except:
                pass

        print(f"  {cmd}: {len(handlers_for_cmd)} хендлеров")

    print("\n" + "=" * 60)
    print("✅ Диагностика завершена")

    await bot.session.close()


if __name__ == "__main__":
    asyncio.run(diagnose())