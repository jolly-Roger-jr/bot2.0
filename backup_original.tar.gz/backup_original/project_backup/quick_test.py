# quick_test.py
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

print("🔍 Быстрая проверка импортов...")

modules = [
    'app.handlers.user.start',
    'app.handlers.user.catalog',
    'app.handlers.user.cart',
    'app.handlers.user.order',
    'app.handlers.user.profile',
    'app.handlers.user.qty',
    'app.handlers.user.back',
    'app.handlers.admin',
    'app.handlers.admin.panel',
    'app.handlers.admin.products',
    'app.handlers.admin.stock',
    'app.handlers.admin.backup',
    'app.handlers.admin.orders',
    'app.handlers.admin.add_product',
    'app.handlers.admin.add_category',
]

for module in modules:
    try:
        m = __import__(module, fromlist=[''])
        if hasattr(m, 'router'):
            r = m.router
            msg = len(list(r.message.handlers))
            cb = len(list(r.callback_query.handlers))
            print(f"✅ {module:45} router ЕСТЬ ({msg} msg, {cb} cb)")
        else:
            print(f"❌ {module:45} router НЕТ")
    except Exception as e:
        print(f"❌ {module:45} ОШИБКА: {e}")

print("\n🎯 Если все router ЕСТЬ (кроме возможно admin), запускайте бота")