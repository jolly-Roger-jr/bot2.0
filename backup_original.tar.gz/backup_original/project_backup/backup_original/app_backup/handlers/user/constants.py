# app/handlers/user/constants.py

# Если будут нужны константы для пользователей
WELCOME_TEXT = "Привет! Выберите категорию товаров:"
NO_PRODUCTS_TEXT = "В этой категории пока нет товаров."