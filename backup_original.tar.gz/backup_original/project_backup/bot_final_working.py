# app/bot_final_working.py

import asyncio
import logging
import importlib
from aiogram import Bot, Dispatcher, Router
from aiogram.fsm.storage.memory import MemoryStorage

from app.config import settings
from app.db.engine import engine
from app.db.models import Base
from app.scheduler import start_scheduler, setup_backup_schedule

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)


async def setup_database():
    """Настройка базы данных"""
    logger.info("Инициализация базы данных...")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("✅ База данных проверена/создана")


def setup_routers_manually(dp: Dispatcher) -> bool:
    """Ручная настройка роутеров - гарантированно работает"""

    logger.info("Настройка роутеров вручную...")

    # Создаем главный роутер
    main_router = Router()

    # Список всех модулей с хендлерами
    handler_modules = [
        # User handlers
        ('app.handlers.user.start', 'user_start'),
        ('app.handlers.user.catalog', 'user_catalog'),
        ('app.handlers.user.cart', 'user_cart'),
        ('app.handlers.user.order', 'user_order'),
        ('app.handlers.user.profile', 'user_profile'),
        ('app.handlers.user.qty', 'user_qty'),
        ('app.handlers.user.back', 'user_back'),

        # Admin handlers
        ('app.handlers.admin', 'admin_main'),  # основной админский
        ('app.handlers.admin.panel', 'admin_panel'),
        ('app.handlers.admin.products', 'admin_products'),
        ('app.handlers.admin.stock', 'admin_stock'),
        ('app.handlers.admin.backup', 'admin_backup'),
        ('app.handlers.admin.orders', 'admin_orders'),
        ('app.handlers.admin.add_product', 'admin_add_product'),
        ('app.handlers.admin.add_category', 'admin_add_category'),
    ]

    success_count = 0

    for module_name, router_name in handler_modules:
        try:
            # Импортируем модуль
            module = importlib.import_module(module_name)

            # Получаем router из модуля
            if hasattr(module, 'router'):
                router = module.router

                # Создаем новый роутер для этого модуля (избегаем конфликтов)
                new_router = Router()

                # Копируем хендлеры из импортированного роутера
                # Хендлеры сообщений
                for handler in router.message.handlers:
                    new_router.message.register(handler.callback, *handler.filters)

                # Хендлеры callback
                for handler in router.callback_query.handlers:
                    new_router.callback_query.register(handler.callback, *handler.filters)

                # Включаем в главный роутер
                main_router.include_router(new_router)

                # Считаем
                msg_count = len(list(new_router.message.handlers))
                cb_count = len(list(new_router.callback_query.handlers))

                logger.info(f"  ✅ {module_name}: {msg_count} msg, {cb_count} cb")
                success_count += 1

            else:
                logger.warning(f"  ⚠️ {module_name}: нет атрибута 'router'")
                # Создаем пустой роутер для этого модуля
                empty_router = Router()
                main_router.include_router(empty_router)

        except Exception as e:
            logger.error(f"  ❌ {module_name}: {e}")

    # Включаем главный роутер в диспетчер
    dp.include_router(main_router)

    # Проверяем результат
    total_msg = len(list(dp.message.handlers))
    total_cb = len(list(dp.callback_query.handlers))

    logger.info(f"📊 ИТОГО: {total_msg} сообщений, {total_cb} callback, {success_count} модулей")

    return total_msg > 0


async def main():
    """Главная функция запуска бота"""

    # 1. Настройка БД
    await setup_database()

    # 2. Настройка планировщика
    logger.info("Настройка планировщика резервного копирования...")
    setup_backup_schedule()
    start_scheduler()
    logger.info("✅ Планировщик запущен")

    # 3. Инициализация бота и диспетчера
    bot = Bot(token=settings.bot_token)
    dp = Dispatcher(storage=MemoryStorage())

    # 4. Настройка роутеров
    if not setup_routers_manually(dp):
        logger.error("❌ Не удалось настроить роутеры!")
        return

    # 5. Проверка хендлеров
    message_handlers = list(dp.message.handlers)
    callback_handlers = list(dp.callback_query.handlers)

    logger.info(f"📊 ФИНАЛЬНАЯ ПРОВЕРКА:")
    logger.info(f"  📨 Хендлеров сообщений: {len(message_handlers)}")
    logger.info(f"  🔄 Хендлеров callback: {len(callback_handlers)}")

    if len(message_handlers) == 0:
        logger.error("❌ Нет хендлеров сообщений!")
        logger.error("Проблема в импорте или регистрации хендлеров")
        return

    # 6. Информация о командах
    logger.info("✅ Основные команды:")
    logger.info("  /start - Главное меню")
    logger.info("  /help - Помощь")
    logger.info("  /cart - Корзина")
    logger.info("  /admin - Админ-панель")

    # 7. Старт бота
    logger.info(f"\n🚀 БОТ ЗАПУЩЕН!")
    logger.info(f"🤖 Admin ID: {settings.admin_id}")
    logger.info(f"🌍 Timezone: {settings.timezone}")
    logger.info(f"📱 Отправьте /start в Telegram для начала работы")

    try:
        await dp.start_polling(bot)
    except KeyboardInterrupt:
        logger.info("⏹ Остановка по запросу пользователя")
    except Exception as e:
        logger.error(f"❌ Ошибка: {e}")
        raise
    finally:
        logger.info("Завершение работы...")
        from app.scheduler import stop_scheduler
        stop_scheduler()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as e:
        logger.error(f"❌ Фатальная ошибка: {e}")