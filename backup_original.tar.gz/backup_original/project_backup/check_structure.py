import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

print("🔍 ПРОВЕРКА СТРУКТУРЫ ПРОЕКТА")
print("=" * 40)

# 1. Проверяем основные файлы
required_files = [
    'app/bot.py',
    'app/config.py',
    'app/db/models.py',
    'app/handlers/__init__.py',
    'app/handlers/user/__init__.py',
    'app/handlers/admin/__init__.py',
]

for file in required_files:
    if os.path.exists(file):
        print(f"✅ {file}")
    else:
        print(f"❌ {file} - НЕ НАЙДЕН")

print("\n📦 Проверка импортов:")

# 2. Проверяем импорты
try:
    from app.config import settings
    print("✅ app.config.settings")
except Exception as e:
    print(f"❌ app.config.settings: {e}")

try:
    from app.db.models import Base
    print("✅ app.db.models.Base")
except Exception as e:
    print(f"❌ app.db.models.Base: {e}")

try:
    from app.handlers import main_router
    print("✅ app.handlers.main_router")
except Exception as e:
    print(f"❌ app.handlers.main_router: {e}")

try:
    from app.handlers.user import router as user_router
    print("✅ app.handlers.user.router")
    
    # Считаем хендлеры
    user_msg = len(list(user_router.message.handlers))
    user_cb = len(list(user_router.callback_query.handlers))
    print(f"   👤 {user_msg} сообщений, {user_cb} callback")
except Exception as e:
    print(f"❌ app.handlers.user.router: {e}")

try:
    from app.handlers.admin import router as admin_router
    print("✅ app.handlers.admin.router")
    
    admin_msg = len(list(admin_router.message.handlers))
    admin_cb = len(list(admin_router.callback_query.handlers))
    print(f"   👑 {admin_msg} сообщений, {admin_cb} callback")
except Exception as e:
    print(f"❌ app.handlers.admin.router: {e}")

print("\n" + "=" * 40)
print("📊 ИТОГО:")
print(f"Всего хендлеров сообщений: {user_msg + admin_msg}")
print(f"Всего хендлеров callback: {user_cb + admin_cb}")
