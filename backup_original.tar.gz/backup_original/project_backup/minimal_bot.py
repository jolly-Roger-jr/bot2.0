# minimal_bot.py
import asyncio
import logging
from aiogram import Bot, Dispatcher, Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message
from aiogram.fsm.storage.memory import MemoryStorage

# Отключаем логи
logging.basicConfig(level=logging.WARNING)


async def test_minimal():
    print("🤖 МИНИМАЛЬНЫЙ БОТ ДЛЯ ТЕСТА...\n")

    # Создаем тестовый бот
    bot = Bot(token="test_token")  # Токен не важен для теста структуры
    dp = Dispatcher(storage=MemoryStorage())

    # Создаем тестовый роутер
    test_router = Router()

    # Добавляем простой хендлер
    @test_router.message(CommandStart())
    async def cmd_start(message: Message):
        await message.answer("✅ Старт работает!")

    @test_router.message(Command("test"))
    async def cmd_test(message: Message):
        await message.answer("✅ Тест работает!")

    # Включаем тестовый роутер
    dp.include_router(test_router)

    # Проверяем хендлеры
    message_handlers = list(dp.message.handlers)
    callback_handlers = list(dp.callback_query.handlers)

    print(f"Тестовый роутер:")
    print(f"  📨 Хендлеров сообщений: {len(message_handlers)}")
    print(f"  🔄 Хендлеров callback: {len(callback_handlers)}")

    if len(message_handlers) > 0:
        print(f"\n✅ Минимальный тест ПРОЙДЕН: хендлеры регистрируются")
        return True
    else:
        print(f"\n❌ Минимальный тест ПРОВАЛЕН: хендлеры не регистрируются")
        return False


if __name__ == "__main__":
    asyncio.run(test_minimal())