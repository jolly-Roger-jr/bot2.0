# bot_aiogram2.py - РАБОЧИЙ БОТ НА AIOGRAM 2.25.1
import asyncio
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.utils import executor

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Токен бота (замените на реальный)
API_TOKEN = 'ВАШ_ТОКЕН'

# Инициализация
bot = Bot(token=API_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)


# Хендлер команды /start
@dp.message_handler(commands=['start'])
async def cmd_start(message: types.Message):
    await message.answer(
        "🐶 <b>Barkery Shop - работает!</b>\n\n"
        "Тестовые команды:\n"
        "/start - это сообщение\n"
        "/help - помощь\n"
        "/cart - корзина\n"
        "/admin - админка",
        parse_mode="HTML"
    )
    logger.info(f"User {message.from_user.id} used /start")


# Хендлер команды /help
@dp.message_handler(commands=['help'])
async def cmd_help(message: types.Message):
    await message.answer("ℹ️ Помощь: /start, /help, /cart, /admin")


# Хендлер команды /cart
@dp.message_handler(commands=['cart'])
async def cmd_cart(message: types.Message):
    await message.answer("🛒 Корзина будет доступна после настройки каталога")


# Тестовый callback
@dp.callback_query_handler(lambda c: c.data == 'test')
async def process_callback_test(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id, '✅ Callback работает!')


# Команда для теста callback
@dp.message_handler(commands=['test_callback'])
async def cmd_test_callback(message: types.Message):
    keyboard = types.InlineKeyboardMarkup()
    keyboard.add(types.InlineKeyboardButton("Нажми меня", callback_data='test'))
    await message.answer("Нажмите кнопку:", reply_markup=keyboard)


if __name__ == '__main__':
    print("🤖 Бот запускается на aiogram 2.25.1...")
    print("📊 Хендлеров зарегистрировано:")
    print(f"  Сообщения: {len(dp.message_handlers.handlers)}")
    print(f"  Callback: {len(dp.callback_query_handlers.handlers)}")

    if len(dp.message_handlers.handlers) > 0:
        print("🚀 Бот готов к работе!")
        print("Замените API_TOKEN в коде на ваш токен из .env")
        executor.start_polling(dp, skip_updates=True)
    else:
        print("❌ Хендлеры не зарегистрированы!")