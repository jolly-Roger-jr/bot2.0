# working_solution_1.py
import asyncio
import logging
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

print("🔧 РЕШЕНИЕ 1: Прямая регистрация через router.message.register()")


async def main():
    from aiogram import Bot, Dispatcher, Router
    from aiogram.filters import CommandStart, Command
    from aiogram.types import Message
    from aiogram.fsm.storage.memory import MemoryStorage

    # 1. Создаем роутер
    router = Router()

    # 2. Определяем функции-обработчики
    async def cmd_start_handler(message: Message):
        await message.answer("✅ /start работает!")

    async def cmd_test_handler(message: Message):
        await message.answer("✅ /test работает!")

    # 3. Регистрируем через router.message.register()
    router.message.register(cmd_start_handler, CommandStart())
    router.message.register(cmd_test_handler, Command("test"))

    # 4. Создаем Dispatcher
    dp = Dispatcher(storage=MemoryStorage())

    # 5. Включаем роутер
    dp.include_router(router)

    # Проверяем
    handlers = list(dp.message.handlers)
    print(f"📊 Хендлеров в Dispatcher: {len(handlers)}")

    if len(handlers) > 0:
        print("🎉 РЕШЕНИЕ РАБОТАЕТ!")
        for i, h in enumerate(handlers, 1):
            print(f"  {i}. {h.callback.__name__}")
    else:
        print("❌ Все еще не работает")

    # Тест с реальным ботом
    try:
        from app.config import settings
        bot = Bot(token=settings.bot_token)
        print("✅ Бот создан с реальным токеном")

        # Запускаем
        print("🚀 Запуск бота...")
        await dp.start_polling(bot)
    except Exception as e:
        print(f"⚠️ Не могу запустить бота: {e}")
        print("Проверьте токен в .env")


if __name__ == "__main__":
    asyncio.run(main())