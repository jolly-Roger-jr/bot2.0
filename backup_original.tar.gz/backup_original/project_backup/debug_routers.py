# debug_routers.py
import sys
import asyncio
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage

print("🔍 ДЕТАЛЬНАЯ ДИАГНОСТИКА РОУТЕРОВ...")

# Проверяем импорты
try:
    from app.config import settings

    print("✅ Настройки импортированы")
except Exception as e:
    print(f"❌ Ошибка импорта настроек: {e}")
    sys.exit(1)

# Пробуем импортировать роутеры
try:
    from app.handlers import main_router

    print(f"✅ Главный роутер импортирован: {main_router}")

    # Проверяем подроутеры
    print(f"\n📊 АНАЛИЗ ГЛАВНОГО РОУТЕРА:")
    print(f"  ID: {id(main_router)}")
    print(f"  Имя: {main_router.__class__.__name__}")

    # Проверяем user роутер
    from app.handlers.user import router as user_router

    print(f"  User роутер в main_router: {'ЕСТЬ' if user_router in main_router.sub_routers else 'НЕТ'}")

    # Проверяем admin роутер
    from app.handlers.admin import router as admin_router

    print(f"  Admin роутер в main_router: {'ЕСТЬ' if admin_router in main_router.sub_routers else 'НЕТ'}")

except Exception as e:
    print(f"❌ Ошибка импорта роутеров: {e}")
    import traceback

    traceback.print_exc()
    sys.exit(1)

# Тестируем фильтры админского роутера
try:
    print(f"\n🔧 ПРОВЕРКА ФИЛЬТРОВ АДМИНА:")
    print(f"  Admin ID из настроек: {settings.admin_id}")
    print(f"  Тип admin_id: {type(settings.admin_id)}")

    from app.handlers.admin import router as admin_router

    filters = list(admin_router.message.filters)
    print(f"  Фильтров message в admin_router: {len(filters)}")

    for i, f in enumerate(filters, 1):
        print(f"    Фильтр {i}: {f}")

except Exception as e:
    print(f"❌ Ошибка проверки фильтров: {e}")

# Проверяем содержимое .env
try:
    import os

    if os.path.exists('.env'):
        print(f"\n📁 СОДЕРЖАНИЕ .env:")
        with open('.env', 'r') as f:
            for line in f:
                if line.strip() and not line.startswith('#'):
                    print(f"  {line.strip()}")
    else:
        print(f"\n❌ Файл .env не найден")
except Exception as e:
    print(f"❌ Ошибка чтения .env: {e}")

print("\n🎯 РЕКОМЕНДАЦИЯ:")
print("Проблема: фильтры в админском роутере могут блокировать все хендлеры.")
print("Решение: убрать фильтры из __init__.py и перенести проверку в каждый хендлер")