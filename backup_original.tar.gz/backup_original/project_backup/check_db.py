# check_db.py

import asyncio
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.db.session import get_session
from sqlalchemy import select
from app.db.models import Category, Product


async def check_database():
    """Проверить содержимое базы данных"""
    print("🔍 Проверка базы данных...")

    async for session in get_session():
        try:
            # Проверяем категории
            result = await session.execute(select(Category))
            categories = result.scalars().all()

            print(f"\n📂 Категории ({len(categories)}):")
            for cat in categories:
                print(f"  • {cat.id}: {cat.name}")

            # Проверяем товары
            result = await session.execute(select(Product))
            products = result.scalars().all()

            print(f"\n📦 Товары ({len(products)}):")
            for prod in products:
                cat_name = prod.category.name if prod.category else "Без категории"
                print(f"  • {prod.id}: {prod.name} ({prod.price} RSD) - {cat_name}")

            if not categories and not products:
                print("\n⚠️ База данных ПУСТА!")
                print("Запустите: python -m app.seed_data")

        except Exception as e:
            print(f"❌ Ошибка при проверке БД: {e}")
            return


if __name__ == "__main__":
    asyncio.run(check_database())