#!/bin/bash
echo "🐕 Запуск Barkery Shop Bot..."
echo "================================"

# Проверка .env файла
if [ ! -f ".env" ]; then
    echo "❌ Файл .env не найден!"
    if [ -f ".env.example" ]; then
        echo "📋 Создаю .env из примера..."
        cp .env.example .env
        echo "✅ Файл .env создан"
        echo "⚠️  Отредактируйте .env: укажите BOT_TOKEN и ADMIN_ID"
        exit 1
    else
        echo "❌ Файл .env.example также не найден"
        exit 1
    fi
fi

# Проверка токена
if grep -q "ваш_токен" .env || grep -q "test" .env; then
    echo "❌ BOT_TOKEN не установлен в .env"
    echo "📝 Отредактируйте файл .env"
    exit 1
fi

echo "✅ Все проверки пройдены"
echo "🚀 Запускаю бота..."
echo ""
echo "📱 Откройте Telegram и найдите вашего бота"
echo "👑 Для админки введите: /admin"
echo ""
echo "================================"
python3 barkery_bot.py
