#!/usr/bin/env python3
"""
Минимальный тест работоспособности проекта
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

print("=== МИНИМАЛЬНЫЙ ТЕСТ РАБОТОСПОСОБНОСТИ ===")

try:
    # 1. Проверка синтаксиса handlers.py
    with open('../handlers.py', 'r') as f:
        handlers_code = f.read()
    
    compile(handlers_code, '../handlers.py', 'exec')
    print("✅ handlers.py компилируется")
    
    # 2. Проверка, что бот технически может запуститься
    import asyncio
    
    async def quick_test():
        try:
            from database import init_db
            await init_db()
            print("✅ База данных инициализируется")
            
            from services import cart_service
            # Просто проверяем, что сервис импортируется
            print("✅ Сервисы импортируются")
            
            return True
        except Exception as e:
            print(f"❌ Ошибка при тесте: {e}")
            return False
    
    success = asyncio.run(quick_test())
    
    if success:
        print("\n✅ ПРОЕКТ ТЕХНИЧЕСКИ РАБОТОСПОСОБЕН")
        print("\nТекущие задачи для реализации:")
        print("1. Telegram логин должен браться автоматически")
        print("2. Данные пользователя должны сохраняться")
        print("3. Сообщение должно показывать имя питомца")
    else:
        print("\n❌ ПРОЕКТ ИМЕЕТ ПРОБЛЕМЫ")
        
except SyntaxError as e:
    print(f"❌ Синтаксическая ошибка в handlers.py: {e}")
except Exception as e:
    print(f"❌ Другая ошибка: {e}")
