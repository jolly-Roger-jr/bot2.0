import re

with open('handlers_fixed.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Исправляем user_id на callback.from_user.id в обработчике handle_quantity
# Сначала находим определение user
pattern = r'user = await cart_service\.get_or_create_user\(callback\.from_user\.id\)'
replacement = r'user = await cart_service.get_or_create_user(callback.from_user.id)\n        user_id = user.id'
content = re.sub(pattern, replacement, content)

# Теперь заменяем все обращения user_id в контексте этого обработчика
# Нужно быть осторожным, чтобы не заменить другие user_id

# Сохраняем исправленную версию
with open('handlers_fixed_v2.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Создан handlers_fixed_v2.py")
