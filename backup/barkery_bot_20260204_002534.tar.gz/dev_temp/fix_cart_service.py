"""
Исправление CartService: добавляем TTL для блокировок
"""

import time
from collections import defaultdict
import asyncio
from typing import Dict, Optional

class FixedCartService:
    """Сервис корзины с TTL для блокировок"""
    
    def __init__(self):
        # Блокировки с меткой времени последнего использования
        self._locks_data: Dict[str, Dict] = {}  # key -> {'lock': asyncio.Lock, 'timestamp': float}
        self._lock_ttl = 3600  # 1 час
        self._cleanup_interval = 300  # 5 минут
        self._last_cleanup = time.time()
        self._internal_lock = asyncio.Lock()  # Для защиты доступа к _locks_data
    
    def _get_lock_key(self, user_id: int, product_id: int = None) -> str:
        """Ключ для блокировки"""
        if product_id:
            return f"user:{user_id}:product:{product_id}"
        return f"user:{user_id}"
    
    async def _get_lock(self, lock_key: str) -> asyncio.Lock:
        """Получить блокировку с обновлением timestamp"""
        async with self._internal_lock:
            # Очистка старых блокировок при необходимости
            current_time = time.time()
            if current_time - self._last_cleanup > self._cleanup_interval:
                await self._cleanup_expired_locks()
                self._last_cleanup = current_time
            
            if lock_key not in self._locks_data:
                self._locks_data[lock_key] = {
                    'lock': asyncio.Lock(),
                    'timestamp': current_time
                }
            else:
                # Обновляем timestamp
                self._locks_data[lock_key]['timestamp'] = current_time
            
            return self._locks_data[lock_key]['lock']
    
    async def _cleanup_expired_locks(self):
        """Очистка устаревших блокировок"""
        async with self._internal_lock:
            current_time = time.time()
            keys_to_remove = []
            
            for key, data in self._locks_data.items():
                if current_time - data['timestamp'] > self._lock_ttl:
                    keys_to_remove.append(key)
            
            for key in keys_to_remove:
                del self._locks_data[key]
            
            if keys_to_remove:
                import logging
                logger = logging.getLogger(__name__)
                logger.debug(f"Очищено {len(keys_to_remove)} устаревших блокировок")
    
    async def add_to_cart(self, user_id: int, product_id: int, quantity: int) -> Dict:
        """Добавить товар в корзину с улучшенной блокировкой"""
        lock_key = self._get_lock_key(user_id, product_id)
        lock = await self._get_lock(lock_key)
        
        async with lock:
            # Оригинальная логика из CartService.add_to_cart
            from database import get_session, Product, CartItem
            from sqlalchemy import select
            
            async with get_session() as session:
                # Проверяем товар
                product = await session.get(Product, product_id)
                if not product or not product.available:
                    return {"success": False, "error": "Товар недоступен"}
                
                # Проверка наличия с учетом типа товара
                if product.unit_type == 'grams':
                    stock = product.stock_grams
                    unit_text = 'г'
                else:  # pieces
                    stock = product.stock_grams
                    unit_text = 'шт'
                
                if quantity > stock:
                    return {"success": False, "error": f"Недостаточно товара. Доступно: {stock}{unit_text}"}
                
                # Находим существующий элемент корзины
                stmt = select(CartItem).where(
                    CartItem.user_id == user_id,
                    CartItem.product_id == product_id
                )
                result = await session.execute(stmt)
                cart_item = result.scalar_one_or_none()
                
                if cart_item:
                    cart_item.quantity = quantity
                else:
                    cart_item = CartItem(
                        user_id=user_id,
                        product_id=product_id,
                        quantity=quantity
                    )
                    session.add(cart_item)
                
                await session.commit()
                
                return {
                    "success": True,
                    "message": f"{product.name} добавлен в корзину ({quantity}г)",
                    "product_name": product.name,
                    "quantity": quantity
                }

# Пример использования:
# cart_service = FixedCartService()
