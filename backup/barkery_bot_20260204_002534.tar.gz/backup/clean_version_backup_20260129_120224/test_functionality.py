#!/usr/bin/env python3
"""
Тест функционала бота
"""
import asyncio
import logging

logging.basicConfig(level=logging.WARNING)

async def test():
    print("🧪 Тестирую функционал бота...")
    print("=" * 50)
    
    try:
        # 1. Проверяем БД
        from database import get_session, Category, Product
        from sqlalchemy import select
        
        async with get_session() as session:
            # Категории
            stmt = select(Category)
            result = await session.execute(stmt)
            categories = result.scalars().all()
            print(f"1. ✅ Категории в БД: {len(categories)} шт.")
            
            # Товары
            stmt = select(Product)
            result = await session.execute(stmt)
            products = result.scalars().all()
            print(f"2. ✅ Товары в БД: {len(products)} шт.")
        
        # 2. Проверяем сервисы
        from services import catalog_service, cart_service
        
        categories = await catalog_service.get_categories()
        print(f"3. ✅ Сервис каталога: {len(categories)} категорий")
        
        # 3. Проверяем админку
        from admin import admin_router
        from handlers import router as main_router
        
        admin_handlers = len(admin_router.message.handlers) + len(admin_router.callback_query.handlers)
        main_handlers = len(main_router.message.handlers) + len(main_router.callback_query.handlers)
        
        print(f"4. ✅ Обработчики админки: {admin_handlers} шт.")
        print(f"5. ✅ Обработчики пользователя: {main_handlers} шт.")
        
        # 4. Проверяем клавиатуры
        from keyboards import main_menu_keyboard, admin_main_keyboard
        
        kb1 = main_menu_keyboard()
        kb2 = admin_main_keyboard()
        
        print(f"6. ✅ Основная клавиатура: {len(kb1.inline_keyboard)} ряда")
        print(f"7. ✅ Админ клавиатура: {len(kb2.inline_keyboard)} ряда")
        
        print("\n🎉 ВСЕ СИСТЕМЫ РАБОТАЮТ КОРРЕКТНО!")
        
        if len(categories) == 0 or len(products) == 0:
            print("\n⚠️  Нет данных в БД. Создать тестовые данные? (y/n)")
            choice = input().strip().lower()
            if choice == 'y':
                print("Создаю тестовые данные...")
                import create_test_data
                await create_test_data.create_test_data()
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    asyncio.run(test())
