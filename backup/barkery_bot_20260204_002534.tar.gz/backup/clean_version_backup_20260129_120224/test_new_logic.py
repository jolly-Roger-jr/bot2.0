#!/usr/bin/env python3
"""
Тест новой логики работы с количеством
"""
import asyncio

async def test():
    print("🧪 Тестирую новую логику работы с количеством...")
    print("=" * 50)
    
    try:
        # Импортируем новые функции
        from handlers import (
            get_temp_quantity_key,
            update_temp_quantity,
            reset_temp_quantity,
            temp_quantities
        )
        
        print("✅ Функции импортированы")
        
        # Тест 1: Работа с временными количествами
        print("\n📊 Тест 1: Работа с временными количествами")
        
        user_id = 12345
        product_id = 1
        
        # Сброс
        reset_temp_quantity(user_id, product_id)
        key = get_temp_quantity_key(user_id, product_id)
        assert temp_quantities.get(key, 0) == 0
        print("   ✅ Сброс количества работает")
        
        # Добавление
        new_qty = update_temp_quantity(user_id, product_id, 100)
        assert new_qty == 100
        assert temp_quantities[key] == 100
        print("   ✅ Добавление 100г работает")
        
        # Еще добавление
        new_qty = update_temp_quantity(user_id, product_id, 100)
        assert new_qty == 200
        print("   ✅ Добавление еще 100г работает")
        
        # Уменьшение
        new_qty = update_temp_quantity(user_id, product_id, -100)
        assert new_qty == 100
        print("   ✅ Уменьшение на 100г работает")
        
        # Не может быть меньше 0
        new_qty = update_temp_quantity(user_id, product_id, -200)
        assert new_qty == 0
        print("   ✅ Количество не может быть меньше 0")
        
        print("\n🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ!")
        print("\n📋 Новая логика:")
        print("1. +/- изменяют предварительное количество")
        print("2. 'Добавить в корзину' добавляет предварительное количество")
        print("3. После добавления счетчик сбрасывается")
        print("4. 'В корзине' показывает реальное количество в корзине")
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    asyncio.run(test())
