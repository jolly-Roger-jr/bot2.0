#!/usr/bin/env python3
"""
Тест роутеров
"""
import asyncio
import logging

logging.basicConfig(level=logging.WARNING)

async def test():
    print("🔧 Тестирую роутеры...")
    print("=" * 50)
    
    try:
        from admin import admin_router
        from handlers import router as main_router
        
        print("✅ Роутеры загружены")
        
        # Проверяем админские обработчики
        print(f"\n📋 Админские обработчики:")
        print(f"   Сообщения: {len(admin_router.message.handlers)}")
        print(f"   Callback: {len(admin_router.callback_query.handlers)}")
        
        # Проверяем основные обработчики
        print(f"\n📋 Основные обработчики:")
        print(f"   Сообщения: {len(main_router.message.handlers)}")
        print(f"   Callback: {len(main_router.callback_query.handlers)}")
        
        # Проверяем, что обработчик неизвестных колбэков игнорирует админские
        print(f"\n🔍 Проверяю фильтрацию админских колбэков:")
        print(f"   Обработчик неизвестных колбэков игнорирует admin_*: {'✅ да' if 'if callback.data.startswith(\"admin_\"):' in open('handlers.py').read() else '❌ нет'}")
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False

asyncio.run(test())
