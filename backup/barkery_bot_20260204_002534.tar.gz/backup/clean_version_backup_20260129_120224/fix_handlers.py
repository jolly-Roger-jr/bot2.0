#!/usr/bin/env python3
"""
Исправление handlers.py
"""
import re

# Читаем файл
with open('handlers.py', 'r') as f:
    content = f.read()

# Ищем незакрытые строки
lines = content.split('\n')
fixed_lines = []

for i, line in enumerate(lines, 1):
    # Исправляем строку 504
    if i == 504 and '"🐾 Помощь по боту Barkery Shop' in line:
        # Закрываем кавычку
        if line.endswith('"'):
            fixed_lines.append(line)
        else:
            fixed_lines.append(line + '"')
    else:
        fixed_lines.append(line)

# Сохраняем исправленный файл
with open('handlers.py', 'w') as f:
    f.write('\n'.join(fixed_lines))

print("✅ handlers.py исправлен")
