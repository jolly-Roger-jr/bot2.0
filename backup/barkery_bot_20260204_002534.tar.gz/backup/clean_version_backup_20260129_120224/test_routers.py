#!/usr/bin/env python3
"""
Тест роутеров
"""
import asyncio
import logging

logging.basicConfig(level=logging.WARNING)

async def test():
    print("🔧 Тестирую роутеры...")
    print("=" * 50)
    
    try:
        from admin import admin_router
        from handlers import router as main_router
        
        print("✅ Роутеры загружены")
        
        # Проверяем админские обработчики
        print("\n📋 Админские обработчики:")
        print(f"   Сообщения: {len(admin_router.message.handlers)}")
        for handler in admin_router.message.handlers:
            print(f"   - {handler.callback.__name__ if hasattr(handler.callback, '__name__') else 'anonymous'}")
        
        print(f"\n   Callback: {len(admin_router.callback_query.handlers)}")
        for handler in admin_router.callback_query.handlers:
            filters = []
            for f in handler.filters:
                try:
                    filters.append(str(f))
                except:
                    filters.append(str(type(f)))
            print(f"   - Колбэк: фильтры={filters}")
        
        print("\n📋 Основные обработчики:")
        print(f"   Сообщения: {len(main_router.message.handlers)}")
        print(f"   Callback: {len(main_router.callback_query.handlers)}")
        
        # Проверяем конкретные админские колбэки
        admin_callbacks = [
            "admin_categories",
            "admin_products", 
            "admin_add_product",
            "admin_back"
        ]
        
        print("\n🔍 Проверяю админские колбэки:")
        for cb in admin_callbacks:
            found = False
            for handler in admin_router.callback_query.handlers:
                # Проверяем фильтры
                for f in handler.filters:
                    try:
                        if cb in str(f):
                            found = True
                            break
                    except:
                        pass
            print(f"   {cb}: {'✅ найден' if found else '❌ не найден'}")
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False

asyncio.run(test())
