#!/usr/bin/env python3
"""
Создание тестовых данных для БД
"""
import asyncio
from database import get_session, Category, Product

async def create_test_data():
    """Создание тестовых данных"""
    print("🧪 Создаю тестовые данные...")
    
    async with get_session() as session:
        # Создаем категории
        categories_data = [
            "Мясные лакомства 🥩",
            "Рыбные лакомства 🐟", 
            "Овощные лакомства 🥕"
        ]
        
        created_categories = []
        for cat_name in categories_data:
            # Проверяем существование
            from sqlalchemy import select
            stmt = select(Category).where(Category.name == cat_name)
            result = await session.execute(stmt)
            existing = result.scalar_one_or_none()
            
            if not existing:
                category = Category(name=cat_name)
                session.add(category)
                created_categories.append(cat_name)
        
        await session.commit()
        
        # Получаем ID категорий
        stmt = select(Category)
        result = await session.execute(stmt)
        categories = result.scalars().all()
        
        category_map = {cat.name: cat.id for cat in categories}
        
        # Создаем тестовые товары
        products_data = [
            {
                "name": "Говяжьи ушки",
                "description": "Натуральные сушеные говяжьи ушки, богатые хрящевой тканью",
                "price": 450.0,
                "stock_grams": 5000,
                "category": "Мясные лакомства 🥩"
            },
            {
                "name": "Куриные шейки",
                "description": "Сушеные куриные шейки, отличное лакомство для зубов",
                "price": 380.0,
                "stock_grams": 3000,
                "category": "Мясные лакомства 🥩"
            },
            {
                "name": "Лососевые косточки",
                "description": "Сушеные косточки лосося, богатые омега-3",
                "price": 520.0,
                "stock_grams": 2500,
                "category": "Рыбные лакомства 🐟"
            },
            {
                "name": "Сушеная морковь",
                "description": "Натуральная сушеная морковь, источник витаминов",
                "price": 280.0,
                "stock_grams": 4000,
                "category": "Овощные лакомства 🥕"
            },
            {
                "name": "Яблочные чипсы",
                "description": "Сушеные яблочные дольки без сахара",
                "price": 320.0,
                "stock_grams": 3500,
                "category": "Овощные лакомства 🥕"
            }
        ]
        
        created_products = []
        for prod in products_data:
            # Проверяем существование
            stmt = select(Product).where(Product.name == prod["name"])
            result = await session.execute(stmt)
            existing = result.scalar_one_or_none()
            
            if not existing:
                product = Product(
                    name=prod["name"],
                    description=prod["description"],
                    price=prod["price"],
                    stock_grams=prod["stock_grams"],
                    category_id=category_map[prod["category"]],
                    available=True
                )
                session.add(product)
                created_products.append(prod["name"])
        
        await session.commit()
        
        print(f"✅ Создано категорий: {len(created_categories)}")
        if created_categories:
            print(f"   {', '.join(created_categories)}")
        
        print(f"✅ Создано товаров: {len(created_products)}")
        if created_products:
            print(f"   {', '.join(created_products)}")
        
        print("\n🎉 Тестовые данные созданы!")
        print("\n📋 Что можно протестировать:")
        print("1. /start - главное меню")
        print("2. 📦 Каталог - должны появиться 3 категории с товарами")
        print("3. Выберите товар, используйте +/- для добавления в корзину")
        print("4. 🛒 Корзина - добавьте несколько товаров")
        print("5. /admin - админ панель (управление категориями и товарами)")

if __name__ == "__main__":
    asyncio.run(create_test_data())
