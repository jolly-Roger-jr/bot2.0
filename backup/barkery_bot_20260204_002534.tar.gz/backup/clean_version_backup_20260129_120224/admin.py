"""
Админка Barkery Shop (полная версия)
"""
import logging
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from sqlalchemy import select

from database import get_session, Product, Category
from config import settings
from keyboards import admin_main_keyboard, admin_categories_keyboard, admin_products_keyboard, admin_product_management_keyboard

logger = logging.getLogger(__name__)
admin_router = Router()

async def is_admin(user_id: int) -> bool:
    return user_id == settings.admin_id

class AdminStates(StatesGroup):
    waiting_category_name = State()
    waiting_product_name = State()
    waiting_product_description = State()
    waiting_product_price = State()
    waiting_product_stock = State()
    waiting_product_category = State()

# Главная админ панель
@admin_router.message(Command("admin"))
async def admin_panel(message: Message):
    """Панель администратора"""
    if not await is_admin(message.from_user.id):
        await message.answer("❌ Доступ запрещен")
        return
    
    await message.answer(
        "👑 Панель администратора Barkery Shop\n\n"
        "Выберите действие:",
        reply_markup=admin_main_keyboard()
    )

# Управление категориями
@admin_router.callback_query(F.data == "admin_categories")
async def admin_categories(callback: CallbackQuery):
    """Управление категориями"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    async with get_session() as session:
        stmt = select(Category).order_by(Category.name)
        result = await session.execute(stmt)
        categories = result.scalars().all()
        
        if not categories:
            await callback.message.edit_text(
                "📦 Управление категориями\n\n"
                "Категорий пока нет.\n"
                "Добавьте первую категорию:",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="➕ Добавить категорию", callback_data="admin_add_category")],
                    [InlineKeyboardButton(text="⬅️ Назад", callback_data="admin_back")]
                ])
            )
            return
        
        categories_list = [{"id": cat.id, "name": cat.name} for cat in categories]
        await callback.message.edit_text(
            "📦 Управление категориями\n\n"
            f"Всего категорий: {len(categories_list)}",
            reply_markup=admin_categories_keyboard(categories_list)
        )
    
    await callback.answer()

# Добавление категории
@admin_router.callback_query(F.data == "admin_add_category")
async def admin_add_category_handler(callback: CallbackQuery, state: FSMContext):
    """Добавление категории"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    await state.set_state(AdminStates.waiting_category_name)
    await callback.message.edit_text(
        "➕ Добавление новой категории\n\n"
        "Введите название категории:"
    )
    await callback.answer()

@admin_router.message(AdminStates.waiting_category_name)
async def process_category_name(message: Message, state: FSMContext):
    """Обработка названия категории"""
    category_name = message.text.strip()
    
    if not category_name or len(category_name) < 2:
        await message.answer("❌ Название слишком короткое. Введите снова:")
        return
    
    async with get_session() as session:
        # Проверяем существование категории
        stmt = select(Category).where(Category.name == category_name)
        result = await session.execute(stmt)
        existing = result.scalar_one_or_none()
        
        if existing:
            await message.answer("❌ Категория с таким названием уже существует. Введите другое:")
            return
        
        # Создаем категорию
        category = Category(name=category_name)
        session.add(category)
        await session.commit()
        await session.refresh(category)
        
        await message.answer(f"✅ Категория '{category_name}' успешно создана! ID: {category.id}")
        await state.clear()
        
        # Возвращаем к списку категорий
        stmt = select(Category).order_by(Category.name)
        result = await session.execute(stmt)
        categories = result.scalars().all()
        categories_list = [{"id": cat.id, "name": cat.name} for cat in categories]
        
        from keyboards import admin_categories_keyboard
        await message.answer(
            f"📦 Категории\n\nВсего категорий: {len(categories_list)}",
            reply_markup=admin_categories_keyboard(categories_list)
        )

# Удаление категории
@admin_router.callback_query(F.data.startswith("admin_delete_category:"))
async def admin_delete_category_handler(callback: CallbackQuery):
    """Удаление категории"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    category_id = int(callback.data.split(":")[1])
    
    async with get_session() as session:
        category = await session.get(Category, category_id)
        if not category:
            await callback.answer("❌ Категория не найдена", show_alert=True)
            return
        
        # Проверяем есть ли товары в категории
        stmt = select(Product).where(Product.category_id == category_id)
        result = await session.execute(stmt)
        products = result.scalars().all()
        
        if products:
            await callback.answer(
                f"❌ Нельзя удалить категорию с товарами. Сначала удалите {len(products)} товар(ов)",
                show_alert=True
            )
            return
        
        # Удаляем категорию
        await session.delete(category)
        await session.commit()
        
        await callback.answer(f"✅ Категория '{category.name}' удалена")
        
        # Обновляем список категорий
        stmt = select(Category).order_by(Category.name)
        result = await session.execute(stmt)
        categories = result.scalars().all()
        categories_list = [{"id": cat.id, "name": cat.name} for cat in categories]
        
        await callback.message.edit_text(
            f"📦 Категории\n\nВсего категорий: {len(categories_list)}",
            reply_markup=admin_categories_keyboard(categories_list)
        )

# Управление товарами
@admin_router.callback_query(F.data == "admin_products")
async def admin_products(callback: CallbackQuery):
    """Управление товарами"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    async with get_session() as session:
        stmt = select(Category).order_by(Category.name)
        result = await session.execute(stmt)
        categories = result.scalars().all()
        
        if not categories:
            await callback.message.edit_text(
                "🛒 Управление товарами\n\n"
                "Сначала создайте категории.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="📦 К категориям", callback_data="admin_categories")],
                    [InlineKeyboardButton(text="⬅️ Назад", callback_data="admin_back")]
                ])
            )
            return
        
        await callback.message.edit_text(
            "🛒 Управление товарами\n\n"
            f"Выберите категорию:",
            reply_markup=admin_products_keyboard(categories)
        )
    
    await callback.answer()

# Товары в выбранной категории
@admin_router.callback_query(F.data.startswith("admin_category_products:"))
async def admin_category_products_handler(callback: CallbackQuery):
    """Товары в выбранной категории"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    category_id = int(callback.data.split(":")[1])
    
    async with get_session() as session:
        category = await session.get(Category, category_id)
        if not category:
            await callback.answer("❌ Категория не найдена", show_alert=True)
            return
        
        stmt = select(Product).where(Product.category_id == category_id)
        result = await session.execute(stmt)
        products = result.scalars().all()
        
        products_list = [
            {
                "id": p.id,
                "name": p.name,
                "price": p.price,
                "stock_grams": p.stock_grams,
                "available": p.available
            }
            for p in products
        ]
        
        await callback.message.edit_text(
            f"🛒 Товары категории: {category.name}\n\n"
            f"Количество товаров: {len(products_list)}",
            reply_markup=admin_product_management_keyboard(products_list, category_id)
        )
    
    await callback.answer()

# Добавление товара
@admin_router.callback_query(F.data == "admin_add_product")
async def admin_add_product_handler(callback: CallbackQuery, state: FSMContext):
    """Добавление товара"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    # Получаем список категорий
    async with get_session() as session:
        stmt = select(Category).order_by(Category.name)
        result = await session.execute(stmt)
        categories = result.scalars().all()
    
    if not categories:
        await callback.answer("❌ Нет категорий. Сначала создайте категорию.", show_alert=True)
        return
    
    await state.update_data(available_categories=categories)
    await state.set_state(AdminStates.waiting_product_name)
    
    categories_text = "\n".join([f"{cat.id}. {cat.name}" for cat in categories])
    
    await callback.message.edit_text(
        "➕ Добавление нового товара\n\n"
        f"Доступные категории:\n{categories_text}\n\n"
        "Шаг 1 из 5: Введите название товара:"
    )
    await callback.answer()

@admin_router.message(AdminStates.waiting_product_name)
async def process_product_name_create(message: Message, state: FSMContext):
    """Обработка названия нового товара"""
    product_name = message.text.strip()
    
    if len(product_name) < 2:
        await message.answer("❌ Название слишком короткое. Введите снова:")
        return
    
    await state.update_data(product_name=product_name)
    await state.set_state(AdminStates.waiting_product_description)
    
    await message.answer(
        f"✅ Название принято: {product_name}\n\n"
        "Шаг 2 из 5: Введите описание товара (или 'нет' если без описания):"
    )

@admin_router.message(AdminStates.waiting_product_description)
async def process_product_description_create(message: Message, state: FSMContext):
    """Обработка описания нового товара"""
    description = message.text.strip()
    if description.lower() == 'нет':
        description = ''
    
    await state.update_data(description=description)
    await state.set_state(AdminStates.waiting_product_price)
    
    await message.answer(
        f"✅ Описание принято\n\n"
        "Шаг 3 из 5: Введите цену за 100 грамм в RSD (только число):\n"
        "Пример: 500"
    )

@admin_router.message(AdminStates.waiting_product_price)
async def process_product_price_create(message: Message, state: FSMContext):
    """Обработка цены нового товара"""
    try:
        price = float(message.text.strip())
        if price <= 0:
            await message.answer("❌ Цена должна быть больше 0. Введите снова:")
            return
        
        await state.update_data(price=price)
        await state.set_state(AdminStates.waiting_product_stock)
        
        await message.answer(
            f"✅ Цена принята: {price} RSD/100г\n\n"
            "Шаг 4 из 5: Введите количество в граммах (только число):\n"
            "Пример: 1000"
        )
        
    except ValueError:
        await message.answer("❌ Введите число. Введите снова:")

@admin_router.message(AdminStates.waiting_product_stock)
async def process_product_stock_create(message: Message, state: FSMContext):
    """Обработка количества для нового товара"""
    try:
        stock = int(message.text.strip())
        if stock < 0:
            await message.answer("❌ Количество не может быть отрицательным. Введите снова:")
            return
        
        await state.update_data(stock=stock)
        
        # Получаем список категорий из состояния
        data = await state.get_data()
        categories = data.get('available_categories', [])
        
        if not categories:
            await message.answer("❌ Список категорий устарел. Начните заново.")
            await state.clear()
            return
        
        categories_text = "\n".join([f"{cat.id}. {cat.name}" for cat in categories])
        
        await state.set_state(AdminStates.waiting_product_category)
        
        await message.answer(
            f"✅ Количество принято: {stock}г\n\n"
            f"Доступные категории:\n{categories_text}\n\n"
            "Шаг 5 из 5: Введите ID категории для товара:"
        )
        
    except ValueError:
        await message.answer("❌ Введите число. Введите снова:")

@admin_router.message(AdminStates.waiting_product_category)
async def process_product_category_create(message: Message, state: FSMContext):
    """Обработка ID категории для нового товара"""
    try:
        category_id = int(message.text.strip())
        
        # Проверяем существование категории
        async with get_session() as session:
            category = await session.get(Category, category_id)
            if not category:
                await message.answer(f"❌ Категория с ID {category_id} не найдена. Введите снова:")
                return
        
        # Получаем остальные данные
        data = await state.get_data()
        product_name = data["product_name"]
        description = data.get("description", "")
        price = data["price"]
        stock = data["stock"]
        
        # Создаем товар
        from database import get_session, Product
        
        async with get_session() as session:
            product = Product(
                name=product_name,
                description=description,
                price=price,
                stock_grams=stock,
                category_id=category_id,
                available=True,
                image_url=None  # Пока без изображения
            )
            
            session.add(product)
            await session.commit()
            await session.refresh(product)
        
        await message.answer(
            f"✅ Товар успешно создан!\n\n"
            f"📦 Название: {product.name}\n"
            f"📝 Описание: {description or 'Нет'}\n"
            f"💰 Цена: {product.price} RSD/100г\n"
            f"⚖️ Количество: {product.stock_grams}г\n"
            f"📂 Категория ID: {category_id} ({category.name})\n\n"
            f"🆔 ID: {product.id}"
        )
        
        await state.clear()
        
        # Возвращаем в админ панель
        from keyboards import admin_main_keyboard
        await message.answer(
            "👑 Админ панель\n\nВыберите действие:",
            reply_markup=admin_main_keyboard()
        )
        
    except ValueError:
        await message.answer("❌ Введите число (ID категории). Введите снова:")
    except Exception as e:
        logger.error(f"Ошибка создания товара: {e}")
        await message.answer("❌ Ошибка при создании товара")
        await state.clear()

# Включение/выключение товара
@admin_router.callback_query(F.data.startswith("admin_toggle_product:"))
async def admin_toggle_product_handler(callback: CallbackQuery):
    """Включение/выключение товара"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    parts = callback.data.split(":")
    product_id = int(parts[1])
    category_id = int(parts[2])
    
    async with get_session() as session:
        product = await session.get(Product, product_id)
        if not product:
            await callback.answer("❌ Товар не найден", show_alert=True)
            return
        
        product.available = not product.available
        await session.commit()
        
        status = "включен" if product.available else "выключен"
        await callback.answer(f"✅ Товар '{product.name}' {status}")
        
        # Обновляем список товаров
        category = await session.get(Category, category_id)
        stmt = select(Product).where(Product.category_id == category_id)
        result = await session.execute(stmt)
        products = result.scalars().all()
        
        products_list = [
            {
                "id": p.id,
                "name": p.name,
                "price": p.price,
                "stock_grams": p.stock_grams,
                "available": p.available
            }
            for p in products
        ]
        
        await callback.message.edit_text(
            f"🛒 Товары категории: {category.name}\n\n"
            f"Количество товаров: {len(products_list)}",
            reply_markup=admin_product_management_keyboard(products_list, category_id)
        )

# Обновление остатков товара
@admin_router.callback_query(F.data.startswith("admin_update_stock:"))
async def admin_update_stock_handler(callback: CallbackQuery, state: FSMContext):
    """Обновление остатков товара"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    parts = callback.data.split(":")
    product_id = int(parts[1])
    category_id = int(parts[2])
    
    await state.update_data(
        product_id=product_id,
        category_id=category_id
    )
    await state.set_state(AdminStates.waiting_product_stock)
    
    async with get_session() as session:
        product = await session.get(Product, product_id)
        if product:
            await callback.message.edit_text(
                f"📦 Обновление остатков\n\n"
                f"Товар: {product.name}\n"
                f"Текущие остатки: {product.stock_grams}г\n\n"
                "Введите новое количество в граммах:"
            )
        else:
            await callback.message.edit_text(
                "📦 Обновление остатков\n\n"
                "Введите новое количество в граммах:"
            )
    
    await callback.answer()

# Удаление товара
@admin_router.callback_query(F.data.startswith("admin_delete_product:"))
async def admin_delete_product_handler(callback: CallbackQuery):
    """Удаление товара"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    parts = callback.data.split(":")
    product_id = int(parts[1])
    category_id = int(parts[2])
    
    async with get_session() as session:
        product = await session.get(Product, product_id)
        if not product:
            await callback.answer("❌ Товар не найден", show_alert=True)
            return
        
        product_name = product.name
        
        # Удаляем товар
        await session.delete(product)
        await session.commit()
        
        await callback.answer(f"✅ Товар '{product_name}' удален")
        
        # Обновляем список товаров
        category = await session.get(Category, category_id)
        stmt = select(Product).where(Product.category_id == category_id)
        result = await session.execute(stmt)
        products = result.scalars().all()
        
        products_list = [
            {
                "id": p.id,
                "name": p.name,
                "price": p.price,
                "stock_grams": p.stock_grams,
                "available": p.available
            }
            for p in products
        ]
        
        await callback.message.edit_text(
            f"🛒 Товары категории: {category.name}\n\n"
            f"Количество товаров: {len(products_list)}",
            reply_markup=admin_product_management_keyboard(products_list, category_id)
        )

# Назад в главное меню админки
@admin_router.callback_query(F.data == "admin_back")
async def admin_back(callback: CallbackQuery):
    """Назад в главное меню админки"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    await callback.message.edit_text(
        "👑 Панель администратора Barkery Shop\n\n"
        "Выберите действие:",
        reply_markup=admin_main_keyboard()
    )
