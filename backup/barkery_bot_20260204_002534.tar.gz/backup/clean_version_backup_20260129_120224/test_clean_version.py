#!/usr/bin/env python3
"""
Тест чистой версии
"""
import asyncio
import sys
import logging

logging.basicConfig(level=logging.WARNING)  # Уменьшаем логи

async def test():
    print("🧪 Тестирую чистую версию...")
    print("=" * 50)
    
    tests_passed = 0
    tests_total = 0
    
    # 1. Конфигурация
    tests_total += 1
    try:
        from config import settings
        if settings.bot_token and settings.bot_token != "test":
            print("✅ Конфигурация загружена")
            tests_passed += 1
        else:
            print("⚠️  Конфигурация: токен не установлен (установите в .env)")
    except Exception as e:
        print(f"❌ Конфигурация: {e}")
    
    # 2. База данных
    tests_total += 1
    try:
        from database import init_db
        await init_db()
        print("✅ База данных инициализирована")
        tests_passed += 1
    except Exception as e:
        print(f"❌ База данных: {e}")
    
    # 3. Клавиатуры
    tests_total += 1
    try:
        from keyboards import main_menu_keyboard, categories_keyboard, product_card_keyboard
        kb1 = main_menu_keyboard()
        kb2 = categories_keyboard([{"id": 1, "name": "Тест"}])
        kb3 = product_card_keyboard(1, 1, 100)
        print(f"✅ Клавиатуры созданы")
        tests_passed += 1
    except Exception as e:
        print(f"❌ Клавиатуры: {e}")
    
    # 4. Хендлеры
    tests_total += 1
    try:
        from handlers import router
        handler_count = len(router.message.handlers) + len(router.callback_query.handlers)
        print(f"✅ Хендлеры загружены ({handler_count} обработчиков)")
        tests_passed += 1
    except Exception as e:
        print(f"❌ Хендлеры: {e}")
        import traceback
        traceback.print_exc()
    
    # 5. Сервисы
    tests_total += 1
    try:
        from services import cart_service, catalog_service
        print("✅ Сервисы загружены")
        tests_passed += 1
    except Exception as e:
        print(f"❌ Сервисы: {e}")
    
    print("=" * 50)
    print(f"📊 Результаты: {tests_passed}/{tests_total}")
    
    success_rate = (tests_passed / tests_total) * 100
    print(f"📈 Успешность: {success_rate:.1f}%")
    
    if success_rate >= 80:
        print("\n🎉 ГОТОВО К ЗАПУСКУ!")
        print("\n📋 ИНСТРУКЦИЯ:")
        print("1. Настройте .env файл:")
        print("   cp .env.example .env")
        print("   # Отредактируйте .env, установите BOT_TOKEN и ADMIN_ID")
        print("2. Запустите бота:")
        print("   python3 barkery_bot.py")
        print("3. Проверьте функционал:")
        print("   - /start - главное меню")
        print("   - 📦 Каталог - просмотр товаров")
        print("   - 🛒 Корзина - добавление товаров")
        print("   - /admin - админ панель (только для ADMIN_ID)")
        return True
    else:
        print("\n⚠️  Есть проблемы, требуются исправления")
        return False

if __name__ == "__main__":
    asyncio.run(test())
