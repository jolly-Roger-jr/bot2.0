"""
Админка Barkery Shop (полная исправленная версия)
"""
import logging
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from sqlalchemy import select
from database import get_session, Product, Category
from config import settings
from keyboards import admin_main_keyboard, admin_categories_keyboard, admin_products_keyboard, admin_product_management_keyboard

logger = logging.getLogger(__name__)
admin_router = Router()

async def is_admin(user_id: int) -> bool:
    return user_id == settings.admin_id

class AdminStates(StatesGroup):
    waiting_category_name = State()
    waiting_edit_category_name = State()
    waiting_product_name = State()
    waiting_product_description = State()
    waiting_product_price = State()
    waiting_product_stock = State()
    waiting_product_unit_type = State()
    waiting_product_image = State()
    waiting_product_category = State()
    waiting_edit_field = State()
    waiting_edit_value = State()

# Главная админ панель
@admin_router.message(Command("admin"))
async def admin_panel(message: Message):
    """Панель администратора"""
    if not await is_admin(message.from_user.id):
        await message.answer("❌ Доступ запрещен")
        return
    await message.answer(
        "👑 Панель администратора Barkery Shop\n\n"
        "Выберите действие:",
        reply_markup=admin_main_keyboard()
    )

# Управление категориями
@admin_router.callback_query(F.data == "admin_categories")
async def admin_categories(callback: CallbackQuery):
    """Управление категориями"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        stmt = select(Category).order_by(Category.name)
        result = await session.execute(stmt)
        categories = result.scalars().all()
        if not categories:
            await callback.message.edit_text(
                "📦 Управление категориями\n\n"
                "Категорий нет. Добавьте первую категорию!",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="➕ Добавить категорию", callback_data="admin_add_category")],
                    [InlineKeyboardButton(text="⬅️ Назад", callback_data="admin_back")]
                ])
            )
            return
        categories_list = [{"id": cat.id, "name": cat.name} for cat in categories]
        await callback.message.edit_text(
            "📦 Управление категориями\n\n"
            f"Всего категорий: {len(categories_list)}",
            reply_markup=admin_categories_keyboard(categories_list)
        )
    await callback.answer()

# Добавление категории
@admin_router.callback_query(F.data == "admin_add_category")
async def admin_add_category_handler(callback: CallbackQuery, state: FSMContext):
    """Добавление категории"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    await state.set_state(AdminStates.waiting_category_name)
    await callback.message.edit_text(
        "➕ Добавление новой категории\n\n"
        "Введите название категории:"
    )
    await callback.answer()

@admin_router.message(AdminStates.waiting_category_name)
async def process_category_name(message: Message, state: FSMContext):
    """Обработка названия категории"""
    category_name = message.text.strip()
    if not category_name or len(category_name) < 2:
        await message.answer("❌ Название слишком короткое. Введите снова:")
        return
    async with get_session() as session:
        # Проверяем существование категории
        stmt = select(Category).where(Category.name == category_name)
        result = await session.execute(stmt)
        existing = result.scalar_one_or_none()
        if existing:
            await message.answer("❌ Категория с таким названием уже существует. Введите другое:")
            return
        # Создаем категорию
        category = Category(name=category_name)
        session.add(category)
        await session.commit()
        await session.refresh(category)
        await message.answer(f"✅ Категория '{category_name}' успешно создана! ID: {category.id}")
        await state.clear()
        # Возвращаем к списку категорий
        stmt = select(Category).order_by(Category.name)
        result = await session.execute(stmt)
        categories = result.scalars().all()
        categories_list = [{"id": cat.id, "name": cat.name} for cat in categories]
        from keyboards import admin_categories_keyboard
        await message.answer(
            f"📦 Категории\n\nВсего категорий: {len(categories_list)}",
            reply_markup=admin_categories_keyboard(categories_list)
        )

# Редактирование категории
@admin_router.callback_query(F.data.startswith("admin_edit_category:"))
async def admin_edit_category_handler(callback: CallbackQuery, state: FSMContext):
    """Редактирование категории"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    category_id = int(callback.data.split(":")[1])
    await state.update_data(edit_category_id=category_id)
    await state.set_state(AdminStates.waiting_edit_category_name)
    async with get_session() as session:
        category = await session.get(Category, category_id)
        if category:
            await callback.message.edit_text(
                f"✏️ Редактирование категории\n\n"
                f"Текущее название: {category.name}\n\n"
                "Введите новое название категории:"
            )
    await callback.answer()

@admin_router.message(AdminStates.waiting_edit_category_name)
async def process_edit_category_name(message: Message, state: FSMContext):
    """Обработка нового названия категории"""
    new_name = message.text.strip()
    if len(new_name) < 2:
        await message.answer("❌ Название слишком короткое. Введите снова:")
        return
    data = await state.get_data()
    category_id = data.get("edit_category_id")
    async with get_session() as session:
        category = await session.get(Category, category_id)
        if not category:
            await message.answer("❌ Категория не найдена")
            await state.clear()
            return
        # Проверяем нет ли другой категории с таким названием
        from sqlalchemy import select
        stmt = select(Category).where(Category.name == new_name, Category.id != category_id)
        result = await session.execute(stmt)
        existing = result.scalar_one_or_none()
        if existing:
            await message.answer("❌ Категория с таким названием уже существует. Введите другое:")
            return
        old_name = category.name
        category.name = new_name
        await session.commit()
        await message.answer(f"✅ Категория переименована: {old_name} → {new_name}")
        # Возвращаем к списку категорий
        stmt = select(Category).order_by(Category.name)
        result = await session.execute(stmt)
        categories = result.scalars().all()
        categories_list = [{"id": cat.id, "name": cat.name} for cat in categories]
        from keyboards import admin_categories_keyboard
        await message.answer(
            f"📦 Категории\n\nВсего категорий: {len(categories_list)}",
            reply_markup=admin_categories_keyboard(categories_list)
        )
    await state.clear()

# Удаление категории
@admin_router.callback_query(F.data.startswith("admin_delete_category:"))
async def admin_delete_category_handler(callback: CallbackQuery):
    """Удаление категории"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    category_id = int(callback.data.split(":")[1])
    async with get_session() as session:
        category = await session.get(Category, category_id)
        if not category:
            await callback.answer("❌ Категория не найдена", show_alert=True)
            return
        # Проверяем есть ли товары в категории
        stmt = select(Product).where(Product.category_id == category_id)
        result = await session.execute(stmt)
        products = result.scalars().all()
        if products:
            await callback.answer(
                f"❌ Нельзя удалить категорию с товарами. Сначала удалите {len(products)} товар(ов)",
                show_alert=True
            )
            return
        # Удаляем категорию
        await session.delete(category)
        await session.commit()
        await callback.answer(f"✅ Категория '{category.name}' удалена")
        # Обновляем список категорий
        stmt = select(Category).order_by(Category.name)
        result = await session.execute(stmt)
        categories = result.scalars().all()
        categories_list = [{"id": cat.id, "name": cat.name} for cat in categories]
        await callback.message.edit_text(
            f"📦 Категории\n\nВсего категорий: {len(categories_list)}",
            reply_markup=admin_categories_keyboard(categories_list)
        )

# Управление товарами
@admin_router.callback_query(F.data == "admin_products")
async def admin_products(callback: CallbackQuery):
    """Управление товарами"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        stmt = select(Category).order_by(Category.name)
        result = await session.execute(stmt)
        categories = result.scalars().all()
        if not categories:
            await callback.message.edit_text(
                "🛒 Управление товарами\n\n"
                "Сначала создайте категории.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="📦 К категориям", callback_data="admin_categories")],
                    [InlineKeyboardButton(text="⬅️ Назад", callback_data="admin_back")]
                ])
            )
            return
        await callback.message.edit_text(
            "🛒 Управление товарами\n\n"
            f"Выберите категорию:",
            reply_markup=admin_products_keyboard(categories)
        )
    await callback.answer()

# Товары в выбранной категории
@admin_router.callback_query(F.data.startswith("admin_category_products:"))
async def admin_category_products_handler(callback: CallbackQuery):
    """Товары в выбранной категории"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    category_id = int(callback.data.split(":")[1])
    async with get_session() as session:
        category = await session.get(Category, category_id)
        if not category:
            await callback.answer("❌ Категория не найдена", show_alert=True)
            return
        stmt = select(Product).where(Product.category_id == category_id)
        result = await session.execute(stmt)
        products = result.scalars().all()
        products_list = [
            {
                "id": p.id,
                "name": p.name,
                "price": p.price,
                "stock_grams": p.stock_grams,
                "available": p.available
            }
            for p in products
        ]
        await callback.message.edit_text(
            f"🛒 Товары категории: {category.name}\n\n"
            f"Количество товаров: {len(products_list)}",
            reply_markup=admin_product_management_keyboard(products_list, category_id)
        )
    await callback.answer()

# Добавление товара - исправленная версия
@admin_router.callback_query(F.data == "admin_add_product")
async def admin_add_product_handler(callback: CallbackQuery, state: FSMContext):
    """Добавление товара - исправленная версия"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    # Получаем список категорий
    async with get_session() as session:
        stmt = select(Category).order_by(Category.name)
        result = await session.execute(stmt)
        categories = result.scalars().all()
    
    if not categories:
        await callback.answer("❌ Нет категорий. Сначала создайте категорию.", show_alert=True)
        return
    
    await state.update_data(available_categories=categories)
    await state.set_state(AdminStates.waiting_product_name)
    
    categories_text = "\n".join([f"{cat.id}. {cat.name}" for cat in categories])
    await callback.message.edit_text(
        "➕ Добавление нового товара\n\n"
        f"Доступные категории:\n{categories_text}\n\n"
        "Шаг 1 из 6: Введите название товара:"
    )
    await callback.answer()

@admin_router.message(AdminStates.waiting_product_name)
async def process_product_name_create(message: Message, state: FSMContext):
    """Обработка названия нового товара"""
    product_name = message.text.strip()
    if len(product_name) < 2:
        await message.answer("❌ Название слишком короткое. Введите снова:")
        return
    
    await state.update_data(product_name=product_name)
    await state.set_state(AdminStates.waiting_product_description)
    await message.answer(
        f"✅ Название принято: {product_name}\n\n"
        "Шаг 2 из 6: Введите описание товара (или 'нет' если без описания):"
    )

@admin_router.message(AdminStates.waiting_product_description)
async def process_product_description_create(message: Message, state: FSMContext):
    """Обработка описания нового товара"""
    description = message.text.strip()
    if description.lower() == 'нет':
        description = ''
    
    await state.update_data(description=description)
    await state.set_state(AdminStates.waiting_product_price)
    await message.answer(
        f"✅ Описание принято\n\n"
        "Шаг 3 из 6: Введите цену в формате цена/шт или цена/гр:\n"
        "Пример для штучного товара: 750/шт\n"
        "Пример для весового товара: 500/гр"
    )

@admin_router.message(AdminStates.waiting_product_price)
async def process_product_price_create(message: Message, state: FSMContext):
    """Обработка цены нового товара с определением единиц измерения"""
    try:
        text = message.text.strip().lower()
        
        # Определяем единицы измерения
        if '/шт' in text:
            # Товар штучный
            price_text = text.replace('/шт', '').strip()
            unit_type = 'pieces'
            measurement_step = 1
            unit_text = 'штук'
            price_label = 'RSD/шт'
        elif '/гр' in text:
            # Товар весовой
            price_text = text.replace('/гр', '').strip()
            unit_type = 'grams'
            measurement_step = 100
            unit_text = 'грамм'
            price_label = 'RSD/100г'
        else:
            # По умолчанию - граммы (для обратной совместимости)
            price_text = text
            unit_type = 'grams'
            measurement_step = 100
            unit_text = 'грамм'
            price_label = 'RSD/100г'
        
        price = float(price_text)
        if price <= 0:
            await message.answer("❌ Цена должна быть больше 0. Введите снова:")
            return

        await state.update_data(
            price=price,
            unit_type=unit_type,
            measurement_step=measurement_step
        )
        
        # Пропускаем шаг выбора единиц измерения
        await state.set_state(AdminStates.waiting_product_stock)
        await message.answer(
            f"✅ Цена принята: {price} {price_label}\n"
            f"✅ Единицы измерения: {unit_text} (шаг: {measurement_step})\n\n"
            "Шаг 4 из 6: Введите количество (только число):\n"
            f"Для {unit_text}: {1000 if unit_type == 'grams' else 50} "
            f"(это {1000 if unit_type == 'grams' else 50} {unit_text})"
        )
    except ValueError:
        await message.answer("❌ Введите число в формате: цена/шт или цена/гр\n"
                           "Пример: 750/шт или 500/гр")

@admin_router.message(AdminStates.waiting_product_stock)
async def process_product_stock_create(message: Message, state: FSMContext):
    """Обработка количества для нового товара"""
    try:
        stock = int(message.text.strip())
        if stock < 0:
            await message.answer("❌ Количество не может быть отрицательным. Введите снова:")
            return

        await state.update_data(stock=stock)
        
        # Получаем данные из состояния для отображения правильных единиц
        data = await state.get_data()
        unit_type = data.get('unit_type', 'grams')
        measurement_step = data.get('measurement_step', 100)
        unit_text = 'грамм' if unit_type == 'grams' else 'штук'
        
        # Пропускаем шаг выбора единиц (они уже определены при вводе цены)
        await state.set_state(AdminStates.waiting_product_image)
        
        await message.answer(
            f"✅ Количество принято: {stock} {unit_text}\n"
            f"✅ Единицы измерения: {unit_text} (шаг: {measurement_step})\n\n"
            "Шаг 5 из 6: Загрузите изображение товара.\n"
            "Или отправьте 'пропустить' если без изображения:"
        )
    except ValueError:
        await message.answer("❌ Введите число. Введите снова:")

@admin_router.message(AdminStates.waiting_product_unit_type)
async def process_product_unit_type(message: Message, state: FSMContext):
    """Обработка единиц измерения товара"""
    unit_choice = message.text.strip()
    
    if unit_choice == '1':
        unit_type = 'grams'
        measurement_step = 100
        unit_text = 'грамм'
    elif unit_choice == '2':
        unit_type = 'pieces'
        measurement_step = 1
        unit_text = 'штук'
    else:
        await message.answer("❌ Введите '1' или '2':")
        return
    
    await state.update_data(unit_type=unit_type, measurement_step=measurement_step)
    await state.set_state(AdminStates.waiting_product_image)
    
    await message.answer(
        f"✅ Единицы измерения приняты: {unit_text} (шаг: {measurement_step})\n\n"
        "Шаг 6 из 6: Загрузите изображение товара.\n"
        "Или отправьте 'пропустить' если без изображения:"
    )

@admin_router.message(AdminStates.waiting_product_image)
async def process_product_image(message: Message, state: FSMContext):
    """Обработка изображения товара"""
    image_url = None

    if message.text and message.text.strip().lower() in ['пропустить', 'skip', 'без изображения']:
        await message.answer("✅ Пропускаем загрузку изображения")
    elif message.photo:
        # Используем file_id от телеграма
        image_url = message.photo[-1].file_id
        await message.answer(f"✅ Изображение получено")
    else:
        await message.answer("❌ Пожалуйста, загрузите изображение или отправьте 'пропустить'")
        return

    await state.update_data(image_url=image_url)

    # Получаем список категорий из состояния
    data = await state.get_data()
    categories = data.get('available_categories', [])

    if not categories:
        # Если категории утеряны, получаем их заново из БД
        from database import get_session, Category
        from sqlalchemy import select
        
        async with get_session() as session:
            stmt = select(Category).order_by(Category.name)
            result = await session.execute(stmt)
            categories = result.scalars().all()
            
            if categories:
                # Сохраняем в состоянии
                await state.update_data(available_categories=categories)
                categories_text = "\n".join([f"{cat.id}. {cat.name}" for cat in categories])
                
                await state.set_state(AdminStates.waiting_product_category)
                await message.answer(
                    f"✅ Изображение обработано\n\n"
                    f"Доступные категории:\n{categories_text}\n\n"
                    "Шаг 6 из 6: Введите ID категории для товара:"
                )
                return
            else:
                await message.answer("❌ В базе данных нет категорий. Сначала создайте категории.")
                await state.clear()
                return

    # Если категории есть, продолжаем как обычно
    categories_text = "\n".join([f"{cat.id}. {cat.name}" for cat in categories])
    await state.set_state(AdminStates.waiting_product_category)

    await message.answer(
        f"✅ Изображение обработано\n\n"
        f"Доступные категории:\n{categories_text}\n\n"
        "Шаг 6 из 6: Введите ID категории для товара:"
    )
@admin_router.message(AdminStates.waiting_product_category)
async def process_product_category(message: Message, state: FSMContext):
    """Обработка категории товара"""
    try:
        category_id = int(message.text.strip())
        
        # Получаем данные из состояния
        data = await state.get_data()
        categories = data.get('available_categories', [])
        
        # Проверяем существование категории
        category_exists = False
        for cat in categories:
            if cat.id == category_id:
                category_exists = True
                break
        
        if not category_exists:
            await message.answer(f"❌ Категория с ID {category_id} не найдена. Введите ID из списка:")
            return
        
                # Создаем товар
        async with get_session() as session:
            # Проверяем наличие всех необходимых данных
            required_fields = ['product_name', 'price', 'stock', 'unit_type', 'measurement_step', 'category_id']
            missing = []
            for field in required_fields:
                if field not in data:
                    missing.append(field)
            
            if missing:
                await message.answer(f"❌ Ошибка: отсутствуют данные: {missing}")
                await state.clear()
                return
            
            product = Product(
                name=data['product_name'],
                description=data.get('description', ''),
                price=data['price'],
                stock_grams=data['stock'],
                image_url=data.get('image_url'),
                unit_type=data.get('unit_type', 'grams'),
                measurement_step=data.get('measurement_step', 100),
                available=True,
                is_active=True,
                category_id=category_id
            )
            
            session.add(product)
            await session.commit()
            await session.refresh(product)
        
        await message.answer(
            f"✅ Товар успешно создан!\n\n"
            f"Название: {product.name}\n"
            f"Цена: {product.price} RSD/{'100г' if product.unit_type == 'grams' else 'шт'}\n"
            f"Количество: {product.stock_grams} ({'грамм' if product.unit_type == 'grams' else 'штук'})\n"
            f"Категория ID: {product.category_id}\n"
            f"Товар ID: {product.id}"
        )
        
        # Возвращаем к списку товаров
        await state.clear()
        from keyboards import admin_main_keyboard
        await message.answer(
            "👑 Панель администратора\n\nВыберите действие:",
            reply_markup=admin_main_keyboard()
        )
        
    except ValueError:
        await message.answer("❌ Введите число (ID категории):")
    except Exception as e:
        logger.error(f"Ошибка создания товара: {e}")
        logger.error(f"Данные в состоянии: {data}")
        import traceback
        logger.error(f"Трассировка: {traceback.format_exc()}")
        await message.answer(f"❌ Ошибка при создании товара: {str(e)}")
        await state.clear()

@admin_router.callback_query(F.data.startswith("admin_toggle_product:"))
async def admin_toggle_product_handler(callback: CallbackQuery):
    """Включение/выключение товара"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    parts = callback.data.split(":")
    product_id = int(parts[1])
    category_id = int(parts[2])
    async with get_session() as session:
        product = await session.get(Product, product_id)
        if not product:
            await callback.answer("❌ Товар не найден", show_alert=True)
            return
        product.available = not product.available
        await session.commit()
        status = "включен" if product.available else "выключен"
        await callback.answer(f"✅ Товар '{product.name}' {status}")
        # Обновляем список товаров
        category = await session.get(Category, category_id)
        stmt = select(Product).where(Product.category_id == category_id)
        result = await session.execute(stmt)
        products = result.scalars().all()
        products_list = [
            {
                "id": p.id,
                "name": p.name,
                "price": p.price,
                "stock_grams": p.stock_grams,
                "available": p.available
            }
            for p in products
        ]
        await callback.message.edit_text(
            f"🛒 Товары категории: {category.name}\n\n"
            f"Количество товаров: {len(products_list)}",
            reply_markup=admin_product_management_keyboard(products_list, category_id)
        )

# Обновление остатков товара
@admin_router.callback_query(F.data.startswith("admin_update_stock:"))
async def admin_update_stock_handler(callback: CallbackQuery, state: FSMContext):
    """Обновление остатков товара"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    parts = callback.data.split(":")
    product_id = int(parts[1])
    category_id = int(parts[2])
    await state.update_data(
        product_id=product_id,
        category_id=category_id
    )
    await state.set_state(AdminStates.waiting_edit_field)  # Используем общее состояние для редактирования
    async with get_session() as session:
        product = await session.get(Product, product_id)
        if product:
            await state.update_data(edit_field='stock_grams')
            await callback.message.edit_text(
                f"📦 Обновление остатков\n\n"
                f"Товар: {product.name}\n"
                f"Текущие остатки: {product.stock_grams}г\n\n"
                "Введите новое количество:"
            )
        else:
            await callback.message.edit_text(
                "📦 Обновление остатков\n\n"
                "Введите новое количество:"
            )
    await callback.answer()

# Редактирование названия товара
@admin_router.callback_query(F.data.startswith("admin_edit_product_name:"))
async def admin_edit_product_name_handler(callback: CallbackQuery, state: FSMContext):
    """Редактирование названия товара"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    parts = callback.data.split(":")
    product_id = int(parts[1])
    category_id = int(parts[2])
    await state.update_data(
        product_id=product_id,
        category_id=category_id,
        edit_field='name'
    )
    await state.set_state(AdminStates.waiting_edit_field)
    async with get_session() as session:
        product = await session.get(Product, product_id)
        if product:
            await callback.message.edit_text(
                f"✏️ Редактирование названия\n\n"
                f"Товар: {product.name}\n"
                f"Текущее название: {product.name}\n\n"
                "Введите новое название товара:"
            )
        else:
            await callback.message.edit_text(
                f"✏️ Редактирование названия\n\n"
                "Введите новое название товара:"
            )
    await callback.answer()

# Редактирование цены товара
@admin_router.callback_query(F.data.startswith("admin_edit_product_price:"))
async def admin_edit_product_price_handler(callback: CallbackQuery, state: FSMContext):
    """Редактирование цены товара"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    parts = callback.data.split(":")
    product_id = int(parts[1])
    category_id = int(parts[2])
    await state.update_data(
        product_id=product_id,
        category_id=category_id,
        edit_field='price'
    )
    await state.set_state(AdminStates.waiting_edit_field)
    async with get_session() as session:
        product = await session.get(Product, product_id)
        if product:
            await callback.message.edit_text(
                f"💰 Редактирование цены\n\n"
                f"Товар: {product.name}\n"
                f"Текущая цена: {product.price} RSD/{'100г' if product.unit_type == 'grams' else 'шт'}\n\n"
                "Введите новую цену:"
            )
        else:
            await callback.message.edit_text(
                f"💰 Редактирование цены\n\n"
                "Введите новую цену:"
            )
    await callback.answer()

# Редактирование единиц измерения товара
@admin_router.callback_query(F.data.startswith("admin_edit_product_units:"))
async def admin_edit_product_units_handler(callback: CallbackQuery, state: FSMContext):
    """Редактирование единиц измерения товара"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    parts = callback.data.split(":")
    product_id = int(parts[1])
    category_id = int(parts[2])
    await state.update_data(
        product_id=product_id,
        category_id=category_id
    )
    await state.set_state(AdminStates.waiting_product_unit_type)
    async with get_session() as session:
        product = await session.get(Product, product_id)
        if product:
            current_unit = "грамм" if product.unit_type == 'grams' else "штук"
            await callback.message.edit_text(
                f"📏 Редактирование единиц измерения\n\n"
                f"Товар: {product.name}\n"
                f"Текущие единицы: {current_unit} (шаг: {product.measurement_step})\n\n"
                "Выберите новые единицы измерения товара:\n"
                "1. Граммы (измеряется в граммах, шаг 100г)\n"
                "2. Штуки (измеряется в штуках, шаг 1шт)\n\n"
                "Введите '1' или '2':"
            )
        else:
            await callback.message.edit_text(
                f"📏 Редактирование единиц измерения\n\n"
                "Выберите единицы измерения товара:\n"
                "1. Граммы (измеряется в граммах, шаг 100г)\n"
                "2. Штуки (измеряется в штуках, шаг 1шт)\n\n"
                "Введите '1' или '2':"
            )
    await callback.answer()

@admin_router.message(AdminStates.waiting_edit_field)
async def process_edit_field(message: Message, state: FSMContext):
    """Обработка изменения поля товара"""
    try:
        data = await state.get_data()
        field = data.get('edit_field')
        product_id = data.get('product_id')
        category_id = data.get('category_id')
        
        if not all([field, product_id, category_id]):
            await message.answer("❌ Ошибка данных. Попробуйте снова.")
            await state.clear()
            return
        
        value = message.text.strip()
        
        async with get_session() as session:
            product = await session.get(Product, product_id)
            if not product:
                await message.answer("❌ Товар не найден")
                await state.clear()
                return
            
            # Преобразуем значение в нужный тип
            if field == 'stock_grams':
                new_value = int(value)
                if new_value < 0:
                    await message.answer("❌ Количество не может быть отрицательным. Введите снова:")
                    return
                old_value = product.stock_grams
                product.stock_grams = new_value
            elif field == 'price':
                new_value = float(value)
                if new_value <= 0:
                    await message.answer("❌ Цена должна быть больше 0. Введите снова:")
                    return
                old_value = product.price
                product.price = new_value
            elif field == 'name':
                if len(value) < 2:
                    await message.answer("❌ Название слишком короткое. Введите снова:")
                    return
                old_value = product.name
                product.name = value
            else:
                await message.answer("❌ Неизвестное поле для редактирования")
                await state.clear()
                return
            
            await session.commit()
            await message.answer(f"✅ Товар обновлен: {field} = {value}")
            
            # Возвращаем к списку товаров
            category = await session.get(Category, category_id)
            stmt = select(Product).where(Product.category_id == category_id)
            result = await session.execute(stmt)
            products = result.scalars().all()
            products_list = [
                {
                    "id": p.id,
                    "name": p.name,
                    "price": p.price,
                    "stock_grams": p.stock_grams,
                    "available": p.available
                }
                for p in products
            ]
            await message.answer(
                f"🛒 Товары категории: {category.name}\n\n"
                f"Количество товаров: {len(products_list)}",
                reply_markup=admin_product_management_keyboard(products_list, category_id)
            )
        
        await state.clear()
        
    except ValueError:
        await message.answer("❌ Неверный формат. Введите число:")
    except Exception as e:
        logger.error(f"Ошибка обновления товара: {e}")
        await message.answer("❌ Ошибка обновления товара")
        await state.clear()

# Удаление товара
@admin_router.callback_query(F.data.startswith("admin_delete_product:"))
async def admin_delete_product_handler(callback: CallbackQuery):
    """Удаление товара"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    parts = callback.data.split(":")
    product_id = int(parts[1])
    category_id = int(parts[2])
    async with get_session() as session:
        product = await session.get(Product, product_id)
        if not product:
            await callback.answer("❌ Товар не найден", show_alert=True)
            return
        product_name = product.name
        # Удаляем товар
        await session.delete(product)
        await session.commit()
        await callback.answer(f"✅ Товар '{product_name}' удален")
        # Обновляем список товаров
        category = await session.get(Category, category_id)
        stmt = select(Product).where(Product.category_id == category_id)
        result = await session.execute(stmt)
        products = result.scalars().all()
        products_list = [
            {
                "id": p.id,
                "name": p.name,
                "price": p.price,
                "stock_grams": p.stock_grams,
                "available": p.available
            }
            for p in products
        ]
        await callback.message.edit_text(
            f"🛒 Товары категории: {category.name}\n\n"
            f"Количество товаров: {len(products_list)}",
            reply_markup=admin_product_management_keyboard(products_list, category_id)
        )

# Назад в главное меню админки
@admin_router.callback_query(F.data == "admin_back")
async def admin_back(callback: CallbackQuery):
    """Назад в главное меню админки"""
    if not await is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    await callback.message.edit_text(
        "👑 Панель администратора Barkery Shop\n\n"
        "Выберите действие:",
        reply_markup=admin_main_keyboard()
    )

# Импортируем новый обработчик

# Конец файла admin.py
# Неполный try блок удален
